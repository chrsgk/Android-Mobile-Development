package com.example.amazingfood;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu extends Activity implements View.OnClickListener {

    Button appetizer;
    Button mainCourse;
    Button sides;
    Button deserts;
    Button drinks;
    Button call;
    Button sms;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        appetizer = findViewById(R.id.Btn2);
        mainCourse = findViewById(R.id.Btn3);
        sides = findViewById(R.id.Btn4);
        deserts = findViewById(R.id.Btn5);
        drinks = findViewById(R.id.Btn6);
        call = findViewById(R.id.Btn7);
        sms = findViewById(R.id.Btn8);

        //Here we're going to activate these buttons

        appetizer.setOnClickListener(this);
        mainCourse.setOnClickListener(this);
        sides.setOnClickListener(this);
        deserts.setOnClickListener(this);
        drinks.setOnClickListener(this);
        call.setOnClickListener(this);
        sms.setOnClickListener(this);
    }

    @Override
    public void onClick(View food) {

        switch (food.getId()){

            case R.id.Btn2:
                Intent intentToDoSomething = new Intent(getApplicationContext(), Apetizer.class);
                startActivity(intentToDoSomething);
                break;

            case R.id.Btn3:
                Intent orderSomething = new Intent(getApplicationContext(), MainCourse.class);
                startActivity(orderSomething);
                break;

            case R.id.Btn4:
                Intent sideDish = new Intent(getApplicationContext(),Sides.class);
                startActivity(sideDish);
                break;

            case R.id.Btn5:
                Intent coolDeserts = new Intent(getApplicationContext(),Deserts.class);
                startActivity(coolDeserts);
                break;

            case R.id.Btn6:
                Intent coolDriks = new Intent(getApplicationContext(),Drinks.class);
                startActivity(coolDriks);
                break;

            case R.id.Btn7:
                Uri telephone = Uri.parse("tel:+34656265905");
                Intent firstTry = new Intent(Intent.ACTION_DIAL, telephone);
                startActivity(firstTry);
                break;

            case R.id.Btn8:
                Uri msg = Uri.parse("smsto:+34656265905");
                Intent firstMsgs = new Intent(Intent.ACTION_SENDTO,msg);
                startActivity(firstMsgs);
                break;

        }
    }
}
