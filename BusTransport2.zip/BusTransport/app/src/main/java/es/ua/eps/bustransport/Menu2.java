package es.ua.eps.bustransport;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Menu2 extends Fragment {

    Button home;
    Button schedule;
    Button about;
    Button destination;
    View rootview;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
         rootview = inflater.inflate(R.layout.menu2, container, false);

        home = rootview.findViewById(R.id.Btn1);
        schedule = rootview.findViewById(R.id.Btn2);
        about = rootview.findViewById(R.id.Btn3);
        destination = rootview.findViewById(R.id.Btn4);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentToDoSomething = new Intent(getActivity(), MainActivity.class);
                startActivity(intentToDoSomething);

            }
        });

        schedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentToDoSomething = new Intent(getActivity(), Schedule.class);
                startActivity(intentToDoSomething);

            }
        });

        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentToDoSomething = new Intent(getActivity(), AboutUs.class);
                startActivity(intentToDoSomething);
            }
        });

        destination.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentToDoSomething = new Intent(getActivity(), Destinations.class);
                startActivity(intentToDoSomething);

            }
        });
        return rootview;
    }

}
